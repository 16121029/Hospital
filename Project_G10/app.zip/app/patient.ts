export class Patient{
    p_id:number=0;
    p_Name:string="";
    dob:string="";
    p_gender:string="";
    p_contact_no:number=0;
    p_username:string='';
    p_password:string='';
}