export class AdminLogin{
    username:string='';
    password:string='';
}