export class Feedback{
    p_Id:number=0;
    f_Name:string="";
    l_Name:string="";
    mailId:string="";
    phone_no:number=0;
    address:string='';
    pcomment:string='';
}