import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disease-details',
  templateUrl: './disease-details.component.html',
  styleUrls: ['./disease-details.component.css']
})
export class DiseaseDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
