export class Disease{
    id:number=0;
    dName:string="";
    dsymptoms:string="";
    dtype:string="";
}